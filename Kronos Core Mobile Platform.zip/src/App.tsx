import { useState, useEffect, useMemo } from 'react'
import {
  LayoutDashboard, Server, Bell, Settings, ArrowLeft,
  KeyRound, Fingerprint, Eye, EyeOff, Cpu, Zap, Wifi,
  Plus, Search, RefreshCw, ChevronRight,
  CheckCircle2, XCircle, AlertTriangle, AlertCircle,
  Shield, Lock, CreditCard, BadgeCheck, X, Clock,
  BarChart3, LogOut, Activity, HardDrive,
} from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid,
} from 'recharts'

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen = 'login' | 'main'
type Tab = 'dashboard' | 'servers' | 'alerts' | 'settings'
type Plan = 'empresarial' | 'dedicated'
type ServerStatus = 'online' | 'offline' | 'warning'
type AlertSeverity = 'critical' | 'warning' | 'info'
type LicenseStep = 'plan' | 'calculator' | 'confirm'

interface ServerNode {
  id: string; name: string; cluster: string; ip: string
  latency: number; status: ServerStatus; cpu: number
  memory: number; uptime: string; region: string
}

interface AlertItem {
  id: string; severity: AlertSeverity; message: string
  time: string; server: string; resolved: boolean
}

interface CustomTooltipProps {
  active?: boolean
  payload?: Array<{ value: number; name: string; color: string }>
  label?: string
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const PERF_DATA = [
  { time: '00h', cpu: 45, traffic: 23 },
  { time: '04h', cpu: 32, traffic: 18 },
  { time: '08h', cpu: 67, traffic: 45 },
  { time: '12h', cpu: 89, traffic: 72 },
  { time: '16h', cpu: 76, traffic: 58 },
  { time: '20h', cpu: 55, traffic: 38 },
  { time: '23h', cpu: 48, traffic: 28 },
]

const SERVERS: ServerNode[] = [
  { id: 's1', name: 'PROD-ALPHA-01', cluster: 'US-EAST', ip: '10.0.1.100', latency: 12, status: 'online', cpu: 67, memory: 82, uptime: '127d 14h', region: 'Virginia' },
  { id: 's2', name: 'PROD-BETA-02', cluster: 'EU-WEST', ip: '10.0.2.201', latency: 38, status: 'online', cpu: 45, memory: 61, uptime: '89d 7h', region: 'Frankfurt' },
  { id: 's3', name: 'STG-GAMMA-03', cluster: 'US-WEST', ip: '10.0.3.150', latency: 156, status: 'warning', cpu: 92, memory: 95, uptime: '12d 3h', region: 'Oregon' },
  { id: 's4', name: 'PROD-DELTA-04', cluster: 'APAC', ip: '10.0.4.88', latency: 285, status: 'offline', cpu: 0, memory: 0, uptime: '—', region: 'Singapore' },
  { id: 's5', name: 'DR-EPSILON-05', cluster: 'US-EAST', ip: '10.0.5.222', latency: 18, status: 'online', cpu: 23, memory: 41, uptime: '201d 9h', region: 'N. Virginia' },
  { id: 's6', name: 'CACHE-ZETA-06', cluster: 'EU-WEST', ip: '10.0.6.55', latency: 8, status: 'online', cpu: 15, memory: 38, uptime: '312d 2h', region: 'Amsterdam' },
]

const ALERTS_SEED: AlertItem[] = [
  { id: 'a1', severity: 'critical', message: 'CPU crítico en STG-GAMMA-03 (92%)', time: 'hace 3m', server: 'STG-GAMMA-03', resolved: false },
  { id: 'a2', severity: 'critical', message: 'PROD-DELTA-04 sin respuesta — timeout 30s', time: 'hace 12m', server: 'PROD-DELTA-04', resolved: false },
  { id: 'a3', severity: 'warning', message: 'Memoria al 95% en STG-GAMMA-03', time: 'hace 38m', server: 'STG-GAMMA-03', resolved: false },
  { id: 'a4', severity: 'warning', message: 'Latencia >200ms detectada en APAC', time: 'hace 1h', server: 'PROD-DELTA-04', resolved: false },
  { id: 'a5', severity: 'info', message: 'Backup completado en DR-EPSILON-05', time: 'hace 2h', server: 'DR-EPSILON-05', resolved: true },
  { id: 'a6', severity: 'info', message: 'Certificado SSL renovado — PROD-BETA-02', time: 'hace 5h', server: 'PROD-BETA-02', resolved: true },
]

const PLANS = {
  empresarial: { name: 'Empresarial', base: 299, maxCpu: 20, maxRam: 64, maxStorage: 2000, desc: 'Para equipos de hasta 50 profesionales IT', features: ['20 vCPUs máx', '64 GB RAM', '2 TB Storage', 'SLA 99.9%', 'Soporte 24/7'] },
  dedicated: { name: 'Dedicado', base: 899, maxCpu: 128, maxRam: 512, maxStorage: 20000, desc: 'Infraestructura dedicada para enterprise', features: ['128 vCPUs máx', '512 GB RAM', '20 TB Storage', 'SLA 99.99%', 'Soporte VIP + CSM'] },
}

// ─── Logo ─────────────────────────────────────────────────────────────────────

function KronosLogo({ size = 56 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <filter id="ng" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <filter id="ngs" x="-100%" y="-100%" width="300%" height="300%">
          <feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <linearGradient id="kg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#38BDF8"/><stop offset="100%" stopColor="#10B981"/>
        </linearGradient>
      </defs>
      <polygon points="28,3 51,15.5 51,40.5 28,53 5,40.5 5,15.5" fill="#0F172A" stroke="#334155" strokeWidth="1.5"/>
      <rect x="14" y="14" width="5" height="28" rx="2" fill="url(#kg)" filter="url(#ng)"/>
      <line x1="19" y1="28" x2="40" y2="14" stroke="url(#kg)" strokeWidth="4.5" strokeLinecap="round" filter="url(#ng)"/>
      <line x1="19" y1="28" x2="40" y2="42" stroke="url(#kg)" strokeWidth="4.5" strokeLinecap="round" filter="url(#ng)"/>
      <circle cx="14" cy="14" r="3.5" fill="#38BDF8" filter="url(#ngs)"/>
      <circle cx="14" cy="42" r="3.5" fill="#38BDF8" filter="url(#ngs)"/>
      <circle cx="40" cy="14" r="3.5" fill="#10B981" filter="url(#ngs)"/>
      <circle cx="40" cy="42" r="3.5" fill="#10B981" filter="url(#ngs)"/>
      <circle cx="14" cy="28" r="4.5" fill="#38BDF8" filter="url(#ngs)"/>
    </svg>
  )
}

// ─── Shared atoms ─────────────────────────────────────────────────────────────

function LiveBadge() {
  return (
    <span className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-full text-emerald-400 text-[10px] font-mono font-semibold uppercase tracking-widest">
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot" />
      En vivo
    </span>
  )
}

function StatusDot({ status }: { status: ServerStatus }) {
  const cls = {
    online:  'bg-emerald-400 shadow-[0_0_7px_rgba(16,185,129,0.9)]',
    offline: 'bg-red-500 shadow-[0_0_7px_rgba(244,63,94,0.9)]',
    warning: 'bg-amber-400 shadow-[0_0_7px_rgba(251,191,36,0.9)]',
  }[status]
  return <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${cls}`} />
}

function Bar({ value, variant = 'blue' }: { value: number; variant?: 'blue' | 'green' | 'red' }) {
  const clr = variant === 'blue' ? 'bg-sky-400' : variant === 'green' ? 'bg-emerald-400' : 'bg-red-400'
  const capped = Math.min(100, Math.max(0, value))
  return (
    <div className="h-1.5 w-full bg-slate-700/60 rounded-full overflow-hidden">
      <div className={`h-full ${clr} rounded-full transition-all duration-700`} style={{ width: `${capped}%` }} />
    </div>
  )
}

function ChartTip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-slate-900 border border-slate-700 rounded-xl p-3 text-[11px] shadow-2xl">
      <p className="text-slate-400 font-mono mb-1.5">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="font-semibold font-mono">{p.name}: {p.value}%</p>
      ))}
    </div>
  )
}

interface SliderProps { label: string; value: number; min: number; max: number; unit: string; onChange: (v: number) => void }
function RangeSlider({ label, value, min, max, unit, onChange }: SliderProps) {
  return (
    <div className="mb-5">
      <div className="flex justify-between items-center mb-2">
        <span className="text-slate-400 text-[10px] font-mono uppercase tracking-widest">{label}</span>
        <span className="text-sky-400 font-bold font-mono text-sm">{value.toLocaleString()}{unit}</span>
      </div>
      <input type="range" min={min} max={max} value={value} onChange={e => onChange(Number(e.target.value))} className="w-full cursor-pointer" />
      <div className="flex justify-between text-slate-600 text-[9px] font-mono mt-1.5">
        <span>{min.toLocaleString()}{unit}</span><span>{max.toLocaleString()}{unit}</span>
      </div>
    </div>
  )
}

// ─── TopBars ──────────────────────────────────────────────────────────────────

function TopBarMain({ tab, alertCount, onLicense }: { tab: Tab; alertCount: number; onLicense: () => void }) {
  const titles: Record<Tab, string> = { dashboard: 'KRONOS CORE', servers: 'SERVIDORES', alerts: 'ALERTAS', settings: 'AJUSTES' }
  return (
    <div className="flex items-center justify-between px-4 py-3.5 border-b border-slate-800/80">
      <div className="flex items-center gap-2.5">
        <KronosLogo size={30} />
        <h1 className="text-white font-black text-base tracking-[0.2em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>
          {titles[tab]}
        </h1>
      </div>
      <div className="flex items-center gap-2">
        <button className="relative w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800 transition-colors">
          <Bell size={17} className="text-slate-400" />
          {alertCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full text-[8px] font-bold text-white flex items-center justify-center">
              {alertCount}
            </span>
          )}
        </button>
        <button onClick={onLicense} className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-800 transition-colors">
          <CreditCard size={17} className="text-slate-400" />
        </button>
      </div>
    </div>
  )
}

function TopBarSecondary({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-800/80">
      <button onClick={onBack} className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700/60 flex items-center justify-center hover:bg-slate-700 transition-colors">
        <ArrowLeft size={16} className="text-slate-300" />
      </button>
      <h1 className="text-white font-black text-sm tracking-[0.2em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>{title}</h1>
    </div>
  )
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────

function BottomNav({ tab, setTab, alertCount }: { tab: Tab; setTab: (t: Tab) => void; alertCount: number }) {
  const items: Array<{ id: Tab; Icon: typeof Bell; label: string; badge?: number }> = [
    { id: 'dashboard', Icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'servers',   Icon: Server,          label: 'Servidores' },
    { id: 'alerts',    Icon: Bell,            label: 'Alertas', badge: alertCount },
    { id: 'settings',  Icon: Settings,        label: 'Ajustes' },
  ]
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/80 flex z-30">
      {items.map(({ id, Icon, label, badge }) => (
        <button
          key={id}
          onClick={() => setTab(id)}
          className={`flex-1 flex flex-col items-center gap-1 py-3 relative transition-all ${tab === id ? 'text-sky-400' : 'text-slate-600 hover:text-slate-400'}`}
        >
          {tab === id && (
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-sky-400 rounded-full shadow-[0_0_10px_rgba(56,189,248,0.9)]" />
          )}
          <div className="relative">
            <Icon size={20} />
            {badge !== undefined && badge > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 rounded-full text-[8px] font-bold text-white flex items-center justify-center">
                {badge}
              </span>
            )}
          </div>
          <span className="text-[9px] font-mono tracking-widest uppercase">{label}</span>
        </button>
      ))}
    </div>
  )
}

// ─── Login Screen ─────────────────────────────────────────────────────────────

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [apiKey, setApiKey]   = useState('')
  const [showKey, setShowKey] = useState(false)
  const [error, setError]     = useState('')
  const [loading, setLoading] = useState(false)
  const [bioPulse, setBio]    = useState(false)

  const attempt = () => {
    if (!apiKey.trim()) { setError('La API Key es requerida para autenticar.'); return }
    if (apiKey.trim().length < 8) { setError('API Key inválida — mínimo 8 caracteres.'); return }
    setError(''); setLoading(true)
    setTimeout(() => { setLoading(false); onLogin() }, 1400)
  }

  const biometric = () => {
    setBio(true)
    setTimeout(() => { setBio(false); onLogin() }, 1800)
  }

  return (
    <div className="min-h-screen bg-[#020617] bg-grid flex flex-col items-center justify-center px-6 py-12 relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[400px] bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-sm relative">
        {/* Logo block */}
        <div className="flex flex-col items-center mb-10">
          <div className="mb-5 p-5 rounded-3xl bg-slate-900/80 border border-slate-700/60 glow-blue">
            <KronosLogo size={72} />
          </div>
          <h1 className="text-4xl font-black tracking-[0.35em] text-white" style={{ fontFamily: "'Exo 2', sans-serif" }}>KRONOS</h1>
          <p className="text-sky-400 font-mono text-[11px] tracking-[0.5em] mt-1.5 uppercase">Core Platform</p>
          <div className="flex items-center gap-2 mt-4 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/25 rounded-full">
            <Shield size={10} className="text-emerald-400" />
            <span className="text-emerald-400 font-mono text-[9px] tracking-[0.25em] uppercase">Acceso Seguro · v3.2.1</span>
          </div>
        </div>

        {/* Error banner */}
        {error && (
          <div className="mb-4 flex items-start gap-3 px-4 py-3 bg-red-500/10 border border-red-500/40 rounded-2xl glow-red">
            <AlertCircle size={15} className="text-red-400 mt-0.5 flex-shrink-0" />
            <p className="text-red-400 text-sm leading-snug">{error}</p>
          </div>
        )}

        {/* API Key */}
        <div className="mb-4">
          <label className="block text-slate-400 font-mono text-[10px] tracking-widest uppercase mb-2 pl-1">API Key de Acceso</label>
          <div className="relative">
            <KeyRound size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={e => { setApiKey(e.target.value); setError('') }}
              onKeyDown={e => e.key === 'Enter' && attempt()}
              placeholder="xxxx-xxxx-xxxx-xxxx"
              className={`w-full bg-slate-900 border rounded-2xl pl-11 pr-12 py-4 text-white font-mono text-sm placeholder:text-slate-700 focus:outline-none transition-all ${
                error ? 'border-red-500/60 focus:border-red-500' : 'border-slate-700 focus:border-sky-500/60 focus:shadow-[0_0_0_3px_rgba(56,189,248,0.1)]'
              }`}
            />
            <button onClick={() => setShowKey(!showKey)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
              {showKey ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          </div>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-slate-800" />
          <span className="text-slate-600 text-xs font-mono">o usa biometría</span>
          <div className="flex-1 h-px bg-slate-800" />
        </div>

        {/* Biometric */}
        <button
          onClick={biometric}
          className={`w-full flex items-center justify-center gap-3 py-4 rounded-2xl border transition-all duration-300 ${
            bioPulse
              ? 'bg-sky-500/20 border-sky-400/70 glow-blue'
              : 'bg-slate-900 border-slate-700 hover:border-sky-500/40 hover:bg-slate-800/60'
          }`}
        >
          <Fingerprint size={22} className={bioPulse ? 'text-sky-400 blink' : 'text-slate-500'} />
          <span className={`font-semibold text-sm ${bioPulse ? 'text-sky-300' : 'text-slate-400'}`}>
            {bioPulse ? 'Escaneando huella digital…' : 'Autenticación Biométrica'}
          </span>
        </button>

        {/* Submit */}
        <button
          onClick={attempt}
          disabled={loading}
          className="w-full mt-4 py-4 rounded-2xl bg-sky-400 text-slate-950 font-black text-sm tracking-widest hover:bg-sky-300 active:scale-[0.98] transition-all glow-blue disabled:opacity-60 disabled:cursor-not-allowed"
          style={{ fontFamily: "'Exo 2', sans-serif" }}
        >
          {loading
            ? <span className="flex items-center justify-center gap-2"><RefreshCw size={15} className="spin-slow" />AUTENTICANDO…</span>
            : 'INICIAR SESIÓN'}
        </button>

        <p className="text-center text-slate-700 text-[10px] mt-6 font-mono">Kronos Core · Enterprise Security · AES-256-GCM</p>
      </div>
    </div>
  )
}

// ─── Dashboard Screen ─────────────────────────────────────────────────────────

function DashboardScreen({ onLicense }: { onLicense: () => void }) {
  const [cpu,      setCpu]      = useState(67)
  const [traffic,  setTraffic]  = useState(4.2)
  const [requests, setRequests] = useState(3847)

  useEffect(() => {
    const iv = setInterval(() => {
      setCpu(v      => Math.max(20, Math.min(99, v + (Math.random() - 0.48) * 9)))
      setTraffic(v  => Math.max(0.5, Math.min(9.9, +(v + (Math.random() - 0.5) * 0.9).toFixed(1))))
      setRequests(v => Math.max(200, Math.min(9999, v + Math.floor((Math.random() - 0.5) * 300))))
    }, 2800)
    return () => clearInterval(iv)
  }, [])

  const cpuCrit = cpu > 85

  return (
    <div className="pb-28 px-4 pt-3">
      {/* System status */}
      <div className="mb-4 px-4 py-3.5 bg-emerald-500/8 border border-emerald-500/30 rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex items-center justify-center">
            <CheckCircle2 size={17} className="text-emerald-400" />
          </div>
          <div>
            <p className="text-emerald-300 font-black text-xs tracking-[0.18em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>SISTEMA OPERATIVO</p>
            <p className="text-emerald-600 font-mono text-[10px] mt-0.5">Disponibilidad · SLA Enterprise activo</p>
          </div>
        </div>
        <span className="text-emerald-300 font-black text-xl tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>99.9%</span>
      </div>

      {/* Metrics header */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-white font-black text-xs tracking-[0.2em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>MÉTRICAS EN TIEMPO REAL</h2>
        <LiveBadge />
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        {[
          {
            Icon: Cpu, label: 'CPU', value: `${Math.round(cpu)}`, unit: '%',
            barVal: cpu, barVariant: (cpuCrit ? 'red' : 'blue') as 'blue' | 'red',
            sub: cpuCrit ? 'Crítico' : 'Normal',
          },
          {
            Icon: Activity, label: 'RED', value: traffic.toFixed(1), unit: 'Gb',
            barVal: traffic * 10, barVariant: 'green' as 'green',
            sub: 'Tráfico/s',
          },
          {
            Icon: Zap, label: 'REQ/S', value: (requests / 1000).toFixed(1), unit: 'k',
            barVal: requests / 100, barVariant: 'blue' as 'blue',
            sub: 'Peticiones',
          },
        ].map(({ Icon, label, value, unit, barVal, barVariant, sub }) => (
          <div key={label} className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-3">
            <div className="flex items-center gap-1.5 mb-2">
              <Icon size={11} className="text-sky-400" />
              <span className="text-slate-500 text-[9px] font-mono uppercase tracking-widest">{label}</span>
            </div>
            <p className="text-white font-black text-xl leading-none mb-0.5 tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>
              {value}<span className="text-sky-400 text-[11px]">{unit}</span>
            </p>
            <p className="text-slate-600 font-mono text-[8px] mb-2">{sub}</p>
            <Bar value={barVal} variant={barVariant} />
          </div>
        ))}
      </div>

      {/* Chart */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-white font-bold text-xs tracking-[0.18em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>RENDIMIENTO 24H</h3>
            <p className="text-slate-600 font-mono text-[9px] mt-0.5">CPU · Tráfico de red</p>
          </div>
          <BarChart3 size={13} className="text-slate-600" />
        </div>
        <ResponsiveContainer width="100%" height={130}>
          <AreaChart data={PERF_DATA} margin={{ top: 4, right: 0, bottom: 0, left: -24 }}>
            <defs>
              <linearGradient id="gcpu" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#38BDF8" stopOpacity={0.35} />
                <stop offset="95%" stopColor="#38BDF8" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gtraffic" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#10B981" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
            <XAxis dataKey="time" tick={{ fill: '#475569', fontSize: 9, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#475569', fontSize: 9 }} axisLine={false} tickLine={false} domain={[0, 100]} />
            <Tooltip content={<ChartTip />} />
            <Area type="monotone" dataKey="cpu"     name="CPU"     stroke="#38BDF8" strokeWidth={1.5} fill="url(#gcpu)"     dot={false} />
            <Area type="monotone" dataKey="traffic" name="Tráfico" stroke="#10B981" strokeWidth={1.5} fill="url(#gtraffic)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <Server size={11} className="text-slate-500" />
            <span className="text-slate-500 text-[9px] font-mono uppercase tracking-widest">Nodos</span>
          </div>
          <p className="text-white font-black text-3xl tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>6</p>
          <p className="text-emerald-500 text-[9px] font-mono mt-1">4 online · 1 warn · 1 offline</p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1.5">
            <AlertTriangle size={11} className="text-slate-500" />
            <span className="text-slate-500 text-[9px] font-mono uppercase tracking-widest">Alertas</span>
          </div>
          <p className="text-white font-black text-3xl tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>4</p>
          <p className="text-red-500 text-[9px] font-mono mt-1">2 críticas · 2 warning</p>
        </div>
      </div>

      {/* License CTA */}
      <button
        onClick={onLicense}
        className="w-full flex items-center justify-between px-5 py-4 bg-sky-500/8 border border-sky-500/30 rounded-2xl hover:bg-sky-500/15 active:scale-[0.98] transition-all"
      >
        <div className="flex items-center gap-3">
          <CreditCard size={15} className="text-sky-400" />
          <div className="text-left">
            <p className="text-sky-300 font-bold text-xs tracking-[0.15em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>PLAN EMPRESARIAL ACTIVO</p>
            <p className="text-sky-600 text-[10px] font-mono">Gestionar licencia · Ver facturación</p>
          </div>
        </div>
        <ChevronRight size={15} className="text-sky-500" />
      </button>
    </div>
  )
}

// ─── Servers Screen ───────────────────────────────────────────────────────────

function ServersScreen() {
  const [query,   setQuery]   = useState('')
  const [filter,  setFilter]  = useState<ServerStatus | 'all'>('all')
  const [showAdd, setShowAdd] = useState(false)

  const filtered = useMemo(() =>
    SERVERS.filter(s => {
      const q = query.toLowerCase()
      const matchQ = !q || s.name.toLowerCase().includes(q) || s.cluster.toLowerCase().includes(q) || s.region.toLowerCase().includes(q)
      return matchQ && (filter === 'all' || s.status === filter)
    }),
    [query, filter]
  )

  const latColor = (ms: number) => ms < 50 ? 'text-emerald-400' : ms < 150 ? 'text-amber-400' : 'text-red-400'
  const statusBadge: Record<ServerStatus, string> = {
    online:  'bg-emerald-500/15 text-emerald-400 border-emerald-500/35',
    offline: 'bg-red-500/15 text-red-400 border-red-500/35',
    warning: 'bg-amber-500/15 text-amber-400 border-amber-500/35',
  }

  return (
    <div className="pb-28 px-4 pt-3 relative">
      {/* Search */}
      <div className="relative mb-3">
        <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Buscar cluster, nodo, región…"
          className="w-full bg-slate-800/50 border border-slate-700 rounded-2xl pl-11 pr-4 py-3.5 text-white text-sm placeholder:text-slate-600 font-mono focus:outline-none focus:border-sky-500/60 transition-all"
        />
      </div>

      {/* Filter chips */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
        {(['all', 'online', 'offline', 'warning'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-[9px] font-mono font-bold uppercase tracking-widest border transition-all ${
              filter === f ? 'bg-sky-400 text-slate-950 border-sky-400' : 'bg-slate-800/60 text-slate-500 border-slate-700 hover:border-slate-500'
            }`}
          >
            {f === 'all' ? 'Todos' : f}
          </button>
        ))}
        <span className="ml-auto text-slate-600 text-[9px] font-mono flex-shrink-0 pt-1">{filtered.length} nodos</span>
      </div>

      {/* Cards */}
      <div className="space-y-3">
        {filtered.map(s => (
          <div key={s.id} className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <StatusDot status={s.status} />
                <div>
                  <p className="text-white font-bold text-sm font-mono">{s.name}</p>
                  <p className="text-slate-500 font-mono text-[10px]">{s.cluster} · {s.region}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded-lg border text-[9px] font-mono font-bold tracking-widest ${statusBadge[s.status]}`}>
                {s.status.toUpperCase()}
              </span>
            </div>

            {s.status !== 'offline' && (
              <div className="grid grid-cols-2 gap-3 mb-3">
                {[
                  { key: 'CPU', val: s.cpu,    variant: s.cpu    > 85 ? 'red' : 'blue'  as 'blue' | 'red' },
                  { key: 'MEM', val: s.memory, variant: s.memory > 85 ? 'red' : 'green' as 'green'| 'red' },
                ].map(({ key, val, variant }) => (
                  <div key={key}>
                    <div className="flex justify-between text-[9px] font-mono mb-1.5">
                      <span className="text-slate-500">{key}</span>
                      <span className={val > 85 ? 'text-red-400' : 'text-slate-400'}>{val}%</span>
                    </div>
                    <Bar value={val} variant={variant} />
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <Wifi size={10} className="text-slate-500" />
                  <span className={`font-mono text-xs font-bold ${latColor(s.latency)}`}>{s.latency}ms</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock size={10} className="text-slate-500" />
                  <span className="text-slate-500 font-mono text-[10px]">{s.uptime}</span>
                </div>
              </div>
              <span className="text-slate-600 font-mono text-[9px]">{s.ip}</span>
            </div>
          </div>
        ))}
      </div>

      {/* FAB */}
      <button
        onClick={() => setShowAdd(true)}
        className="fixed bottom-24 right-5 w-14 h-14 rounded-2xl bg-sky-400 text-slate-950 flex items-center justify-center glow-blue hover:bg-sky-300 active:scale-95 transition-all z-20"
      >
        <Plus size={22} />
      </button>

      {/* Add Server Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end justify-center p-4">
          <div className="w-full max-w-[430px] bg-slate-900 border border-slate-700 rounded-3xl p-6">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-black tracking-[0.2em] text-sm" style={{ fontFamily: "'Exo 2', sans-serif" }}>AGREGAR NODO</h3>
              <button onClick={() => setShowAdd(false)} className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-500 hover:text-white transition-colors">
                <X size={16} />
              </button>
            </div>
            <div className="space-y-3">
              {['Nombre del nodo', 'Cluster / Grupo', 'IP o Hostname', 'Puerto SSH (22)'].map(pl => (
                <input key={pl} placeholder={pl}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white text-sm placeholder:text-slate-600 focus:outline-none focus:border-sky-500/60 font-mono transition-all" />
              ))}
            </div>
            <button className="w-full mt-5 py-3.5 rounded-2xl bg-sky-400 text-slate-950 font-black text-sm tracking-widest hover:bg-sky-300 transition-all" style={{ fontFamily: "'Exo 2', sans-serif" }}>
              REGISTRAR NODO
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Alerts Screen ────────────────────────────────────────────────────────────

function AlertsScreen() {
  const [alerts, setAlerts] = useState(ALERTS_SEED)
  const resolve = (id: string) => setAlerts(prev => prev.map(a => a.id === id ? { ...a, resolved: true } : a))

  const SEV = {
    critical: { icon: <XCircle size={15} className="text-red-400" />,      bg: 'bg-red-500/8 border-red-500/30',    badge: 'bg-red-500/20 text-red-400 border-red-500/35',    label: 'CRÍTICA' },
    warning:  { icon: <AlertTriangle size={15} className="text-amber-400" />, bg: 'bg-amber-500/8 border-amber-500/30', badge: 'bg-amber-500/20 text-amber-400 border-amber-500/35', label: 'WARNING' },
    info:     { icon: <CheckCircle2 size={15} className="text-sky-400" />,  bg: 'bg-sky-500/8 border-sky-500/25',    badge: 'bg-sky-500/20 text-sky-400 border-sky-500/30',    label: 'INFO' },
  }

  const active   = alerts.filter(a => !a.resolved)
  const resolved = alerts.filter(a => a.resolved)

  return (
    <div className="pb-28 px-4 pt-3">
      {/* Summary row */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: 'Críticas', count: active.filter(a => a.severity === 'critical').length, color: 'text-red-400' },
          { label: 'Warnings', count: active.filter(a => a.severity === 'warning').length,  color: 'text-amber-400' },
          { label: 'Resueltas', count: resolved.length, color: 'text-emerald-400' },
        ].map(({ label, count, color }) => (
          <div key={label} className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-3 text-center">
            <p className={`font-black text-3xl tabular-nums ${color}`} style={{ fontFamily: "'Exo 2', sans-serif" }}>{count}</p>
            <p className="text-slate-600 text-[9px] font-mono uppercase tracking-widest mt-1">{label}</p>
          </div>
        ))}
      </div>

      {active.length > 0 && (
        <>
          <h2 className="text-red-400 font-black text-[10px] tracking-[0.2em] mb-3 flex items-center gap-2" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            <AlertCircle size={11} />ALERTAS ACTIVAS ({active.length})
          </h2>
          <div className="space-y-3 mb-5">
            {active.map(a => {
              const c = SEV[a.severity]
              return (
                <div key={a.id} className={`border rounded-2xl p-4 ${c.bg}`}>
                  <div className="flex items-center justify-between mb-2.5">
                    <div className="flex items-center gap-2">
                      {c.icon}
                      <span className={`px-2 py-0.5 rounded-lg border text-[9px] font-mono font-bold tracking-widest ${c.badge}`}>{c.label}</span>
                    </div>
                    <span className="text-slate-500 text-[9px] font-mono">{a.time}</span>
                  </div>
                  <p className="text-white text-sm leading-snug mb-2.5">{a.message}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-mono text-[9px]">→ {a.server}</span>
                    <button
                      onClick={() => resolve(a.id)}
                      className="text-[10px] font-mono text-sky-400 hover:text-sky-300 border border-sky-500/35 px-2.5 py-1 rounded-lg transition-colors"
                    >
                      Resolver
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </>
      )}

      {resolved.length > 0 && (
        <>
          <h2 className="text-slate-500 font-black text-[10px] tracking-[0.2em] mb-3 flex items-center gap-2" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            <CheckCircle2 size={11} className="text-emerald-600" />RESUELTAS ({resolved.length})
          </h2>
          <div className="space-y-2">
            {resolved.map(a => (
              <div key={a.id} className="border border-slate-800 rounded-2xl px-4 py-3 opacity-50">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-slate-500 text-sm line-through leading-snug">{a.message}</p>
                  <span className="text-slate-600 text-[9px] font-mono flex-shrink-0">{a.time}</span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

// ─── Settings Screen ──────────────────────────────────────────────────────────

function SettingsScreen({ onLogout }: { onLogout: () => void }) {
  const OPTS = [
    { label: 'Notificaciones Push',   desc: 'Alertas críticas en tiempo real',    on: true  },
    { label: 'Reportes Automáticos',  desc: 'Resumen semanal por email cifrado',   on: true  },
    { label: 'Autenticación 2FA',     desc: 'Capa adicional de seguridad activa',  on: true  },
    { label: 'Modo Alto Contraste',   desc: 'Mejora de accesibilidad visual',      on: false },
  ]
  const [toggles, setToggles] = useState(OPTS.map(o => o.on))

  return (
    <div className="pb-28 px-4 pt-3">
      {/* Profile */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4 mb-4 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-500/25 to-emerald-500/25 border border-sky-500/25 flex items-center justify-center flex-shrink-0">
          <KronosLogo size={32} />
        </div>
        <div>
          <p className="text-white font-bold text-sm" style={{ fontFamily: "'Exo 2', sans-serif" }}>Admin Root</p>
          <p className="text-slate-400 font-mono text-xs">admin@kronos-enterprise.io</p>
          <span className="inline-flex items-center gap-1 mt-1.5 px-2 py-0.5 bg-sky-500/10 border border-sky-500/25 rounded-full text-sky-400 text-[9px] font-mono tracking-widest">
            <Shield size={8} />SUPER ADMIN
          </span>
        </div>
      </div>

      {/* Toggles */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl overflow-hidden mb-4">
        {OPTS.map((o, i) => (
          <div key={o.label} className={`flex items-center justify-between p-4 ${i < OPTS.length - 1 ? 'border-b border-slate-700/50' : ''}`}>
            <div className="mr-3">
              <p className="text-white text-sm font-medium">{o.label}</p>
              <p className="text-slate-500 text-[10px] font-mono mt-0.5">{o.desc}</p>
            </div>
            <button
              onClick={() => setToggles(p => p.map((t, j) => j === i ? !t : t))}
              className={`relative flex-shrink-0 w-11 h-6 rounded-full transition-colors duration-200 ${toggles[i] ? 'bg-sky-400' : 'bg-slate-700'}`}
            >
              <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-200 ${toggles[i] ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </div>
        ))}
      </div>

      {/* System info */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl overflow-hidden mb-4">
        {[
          ['Versión',   'v3.2.1 · Build 2025.09'],
          ['Servidor',  'prod-alpha.kronos.io'],
          ['Región',    'US-EAST · Virginia'],
          ['Cifrado',   'AES-256-GCM · TLS 1.3'],
          ['Licencia',  'Empresarial · Activa'],
        ].map(([k, v], i, a) => (
          <div key={k} className={`flex items-center justify-between px-4 py-3 ${i < a.length - 1 ? 'border-b border-slate-700/40' : ''}`}>
            <span className="text-slate-500 text-xs font-mono">{k}</span>
            <span className="text-slate-300 text-xs font-mono">{v}</span>
          </div>
        ))}
      </div>

      <button
        onClick={onLogout}
        className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl border border-red-500/30 bg-red-500/8 text-red-400 font-black text-sm tracking-widest hover:bg-red-500/15 transition-all"
        style={{ fontFamily: "'Exo 2', sans-serif" }}
      >
        <LogOut size={15} />CERRAR SESIÓN
      </button>
    </div>
  )
}

// ─── License Screen ───────────────────────────────────────────────────────────

function LicenseScreen({ onBack }: { onBack: () => void }) {
  const [step,    setStep]    = useState<LicenseStep>('plan')
  const [plan,    setPlan]    = useState<Plan>('empresarial')
  const [vcpus,   setVcpus]   = useState(8)
  const [ram,     setRam]     = useState(32)
  const [storage, setStorage] = useState(500)

  const P = PLANS[plan]

  const cost = useMemo(() => {
    const base = P.base, cpu = vcpus * 8, ramC = ram * 2, stor = Math.floor(storage * 0.05)
    return { base, cpu, ram: ramC, storage: stor, total: base + cpu + ramC + stor }
  }, [plan, vcpus, ram, storage, P.base])

  const invoiceId = useMemo(() =>
    `KRN-${Date.now().toString(36).toUpperCase().slice(-6)}-${Math.random().toString(36).substring(2,8).toUpperCase()}`,
    [] // stable for this mount
  )

  const handlePlanChange = (p: Plan) => {
    setPlan(p)
    setVcpus(p === 'empresarial' ? 8 : 32)
    setRam(p === 'empresarial' ? 32 : 128)
    setStorage(p === 'empresarial' ? 500 : 2000)
  }

  // ── Confirmation receipt ──
  if (step === 'confirm') return (
    <div className="min-h-screen bg-[#020617] flex flex-col">
      <TopBarSecondary title="COMPROBANTE" onBack={() => setStep('calculator')} />
      <div className="flex-1 px-4 py-4 overflow-y-auto pb-10">
        <div className="flex flex-col items-center py-6 mb-6">
          <div className="w-18 h-18 w-[72px] h-[72px] rounded-3xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mb-4 glow-green">
            <BadgeCheck size={34} className="text-emerald-400" />
          </div>
          <h2 className="text-white font-black text-2xl tracking-[0.2em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>PAGO CONFIRMADO</h2>
          <p className="text-emerald-500 font-mono text-[10px] mt-1.5 tracking-widest">TRANSACCIÓN CIFRADA · AES-256-GCM</p>
        </div>

        {/* Invoice */}
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl overflow-hidden mb-4">
          <div className="px-5 py-4 border-b border-slate-700/50 bg-slate-900/40">
            <div className="flex items-center justify-between">
              <p className="text-white font-black text-xs tracking-[0.2em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>FACTURA KRONOS CORE</p>
              <Lock size={12} className="text-emerald-400" />
            </div>
            <p className="text-slate-500 font-mono text-[10px] mt-1">
              {new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>

          <div className="px-5 py-4 space-y-2">
            {[
              [`Plan ${P.name}`,          `$${cost.base}`],
              [`${vcpus} vCPUs × $8/u`,   `$${cost.cpu}`],
              [`${ram}GB RAM × $2/GB`,     `$${cost.ram}`],
              [`${storage}GB Storage`,     `$${cost.storage}`],
            ].map(([item, price]) => (
              <div key={item} className="flex items-center justify-between py-1.5">
                <span className="text-slate-300 text-sm">{item}</span>
                <span className="text-white font-mono text-sm">{price}</span>
              </div>
            ))}
            <div className="pt-3 mt-1 border-t border-slate-700 flex items-center justify-between">
              <span className="text-white font-black text-sm tracking-wider" style={{ fontFamily: "'Exo 2', sans-serif" }}>TOTAL / MES</span>
              <span className="text-sky-400 font-black text-2xl tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                ${cost.total.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="px-5 py-3.5 bg-slate-900/50 border-t border-slate-700/50">
            <p className="text-slate-600 text-[9px] font-mono mb-1 uppercase tracking-widest">ID de Transacción Cifrada</p>
            <p className="text-sky-400 font-mono text-xs break-all">{invoiceId}</p>
          </div>
        </div>

        <div className="flex items-start gap-3 px-4 py-3.5 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl mb-5">
          <Shield size={13} className="text-emerald-500 mt-0.5 flex-shrink-0" />
          <p className="text-slate-400 text-xs leading-relaxed font-mono">
            Transacción verificada y cifrada con AES-256-GCM. Datos procesados bajo PCI DSS Level 1 con token de factura seguro.
          </p>
        </div>

        <button
          onClick={onBack}
          className="w-full py-4 rounded-2xl bg-sky-400 text-slate-950 font-black text-sm tracking-widest hover:bg-sky-300 transition-all glow-blue"
          style={{ fontFamily: "'Exo 2', sans-serif" }}
        >
          VOLVER AL DASHBOARD
        </button>
      </div>
    </div>
  )

  // ── Calculator ──
  if (step === 'calculator') return (
    <div className="min-h-screen bg-[#020617] flex flex-col">
      <TopBarSecondary title="CONFIGURAR PLAN" onBack={() => setStep('plan')} />
      <div className="flex-1 px-4 py-4 overflow-y-auto pb-10">
        <div className="flex items-center justify-between px-4 py-3 bg-sky-500/8 border border-sky-500/25 rounded-2xl mb-6">
          <div>
            <p className="text-sky-300 font-black text-xs tracking-[0.2em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>PLAN {P.name.toUpperCase()}</p>
            <p className="text-sky-600 text-[10px] font-mono">Base: ${P.base}/mes</p>
          </div>
          <CreditCard size={16} className="text-sky-500" />
        </div>

        <RangeSlider label="vCPUs"           value={vcpus}   min={2}   max={P.maxCpu}     unit=" vCPU" onChange={setVcpus}   />
        <RangeSlider label="Memoria RAM"     value={ram}     min={4}   max={P.maxRam}     unit=" GB"   onChange={setRam}     />
        <RangeSlider label="Almacenamiento"  value={storage} min={100} max={P.maxStorage} unit=" GB"   onChange={setStorage} />

        <div className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-4 mb-5">
          <h3 className="text-white font-black text-xs tracking-[0.2em] mb-3" style={{ fontFamily: "'Exo 2', sans-serif" }}>DESGLOSE DE COSTOS</h3>
          {[
            [`Plan ${P.name}`,             cost.base],
            [`${vcpus} vCPUs × $8`,        cost.cpu],
            [`${ram}GB RAM × $2`,          cost.ram],
            [`${storage}GB × $0.05/GB`,    cost.storage],
          ].map(([label, value]) => (
            <div key={label as string} className="flex justify-between py-1.5 text-xs font-mono">
              <span className="text-slate-400">{label as string}</span>
              <span className="text-white">${value as number}</span>
            </div>
          ))}
          <div className="pt-3 mt-1.5 border-t border-slate-700 flex items-end justify-between">
            <span className="text-white font-black text-sm" style={{ fontFamily: "'Exo 2', sans-serif" }}>TOTAL</span>
            <div className="text-right">
              <span className="text-sky-400 font-black text-3xl tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                ${cost.total.toLocaleString()}
              </span>
              <span className="text-slate-500 text-xs font-mono">/mes</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => setStep('confirm')}
          className="w-full py-4 rounded-2xl bg-sky-400 text-slate-950 font-black text-sm tracking-wider hover:bg-sky-300 transition-all glow-blue"
          style={{ fontFamily: "'Exo 2', sans-serif" }}
        >
          CONFIRMAR PAGO · ${cost.total.toLocaleString()}/mes
        </button>
      </div>
    </div>
  )

  // ── Plan selection ──
  return (
    <div className="min-h-screen bg-[#020617] flex flex-col">
      <TopBarSecondary title="LICENCIA Y PAGO" onBack={onBack} />
      <div className="flex-1 px-4 py-4 overflow-y-auto pb-10">
        <p className="text-slate-400 text-sm mb-5 leading-relaxed">
          Selecciona el plan que mejor se adapta a tu organización. Los costos se ajustan en tiempo real según los recursos configurados.
        </p>

        <div className="space-y-4 mb-6">
          {(Object.entries(PLANS) as Array<[Plan, typeof PLANS.empresarial]>).map(([key, p]) => (
            <button
              key={key}
              onClick={() => handlePlanChange(key)}
              className={`w-full text-left p-5 rounded-2xl border transition-all ${
                plan === key
                  ? 'bg-sky-500/8 border-sky-400/60 glow-blue'
                  : 'bg-slate-800/50 border-slate-700/50 hover:border-slate-600'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-white font-black text-base tracking-[0.1em]" style={{ fontFamily: "'Exo 2', sans-serif" }}>
                      {p.name.toUpperCase()}
                    </p>
                    {key === 'dedicated' && (
                      <span className="px-2 py-0.5 bg-sky-500/20 border border-sky-400/40 rounded-full text-sky-300 text-[9px] font-mono font-bold tracking-widest">
                        PREMIUM
                      </span>
                    )}
                  </div>
                  <p className="text-slate-500 text-xs leading-snug">{p.desc}</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 mt-0.5 transition-colors ${plan === key ? 'border-sky-400' : 'border-slate-600'}`}>
                  {plan === key && <div className="w-full h-full rounded-full bg-sky-400 scale-50" />}
                </div>
              </div>

              <div className="flex items-end gap-1 mb-3">
                <span className="text-sky-400 font-black text-3xl tabular-nums" style={{ fontFamily: "'Exo 2', sans-serif" }}>${p.base}</span>
                <span className="text-slate-500 text-sm font-mono mb-1">/mes base</span>
              </div>

              <ul className="grid grid-cols-2 gap-1.5">
                {p.features.map(f => (
                  <li key={f} className="flex items-center gap-1.5">
                    <CheckCircle2 size={10} className={plan === key ? 'text-sky-400' : 'text-slate-700'} />
                    <span className="text-slate-400 text-[10px] font-mono">{f}</span>
                  </li>
                ))}
              </ul>
            </button>
          ))}
        </div>

        <button
          onClick={() => setStep('calculator')}
          className="w-full py-4 rounded-2xl bg-sky-400 text-slate-950 font-black text-sm tracking-widest hover:bg-sky-300 transition-all glow-blue"
          style={{ fontFamily: "'Exo 2', sans-serif" }}
        >
          CONFIGURAR RECURSOS →
        </button>
      </div>
    </div>
  )
}

// ─── App root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen,      setScreen]      = useState<Screen>('login')
  const [tab,         setTab]         = useState<Tab>('dashboard')
  const [showLicense, setShowLicense] = useState(false)

  const alertCount = ALERTS_SEED.filter(a => !a.resolved).length

  if (screen === 'login') return <LoginScreen onLogin={() => setScreen('main')} />
  if (showLicense)        return <LicenseScreen onBack={() => setShowLicense(false)} />

  return (
    <div className="min-h-screen bg-[#020617] flex justify-center">
      <div className="w-full max-w-[430px] relative flex flex-col min-h-screen">
        <TopBarMain tab={tab} alertCount={alertCount} onLicense={() => setShowLicense(true)} />
        <div className="flex-1 overflow-y-auto">
          {tab === 'dashboard' && <DashboardScreen onLicense={() => setShowLicense(true)} />}
          {tab === 'servers'   && <ServersScreen />}
          {tab === 'alerts'    && <AlertsScreen />}
          {tab === 'settings'  && <SettingsScreen onLogout={() => { setScreen('login'); setTab('dashboard') }} />}
        </div>
        <BottomNav tab={tab} setTab={setTab} alertCount={alertCount} />
      </div>
    </div>
  )
}
